<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 0.01-Pre
    </div>
    <strong> &copy; 2020-2021 <a href="#">Marsel</a>.</strong> All rights
    reserved.
</footer>