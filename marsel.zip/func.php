<?php
include $_SERVER["DOCUMENT_ROOT"] . "/marsel/app/config.php";
include $_SERVER["DOCUMENT_ROOT"] . "/marsel/app/class/class.category.php";
$category = new Category();